// script.js
document.getElementById('payButton').addEventListener('click', function (e) {
  e.preventDefault();

  const emailOrPhone = document.getElementById('emailOrPhone').value;
  const password = document.getElementById('password').value;

  if (!emailOrPhone || !password) {
    alert('Please fill in all fields.');
    return;
  }

  const handler = PaystackPop.setup({
    key: 'your-public-key-here', // Replace with your Paystack public key
    email: emailOrPhone,
    amount: 99900, // R999 in kobo
    currency: 'ZAR',
    callback: function (response) {
      alert('Payment successful! Reference: ' + response.reference);

      // Save user data (optional, requires backend integration)
      localStorage.setItem('user', JSON.stringify({ emailOrPhone, password }));
      window.location.href = 'robot.html'; // Redirect to the trading robot page
    },
    onClose: function () {
      alert('Payment window closed.');
    }
  });

  handler.openIframe();
});
