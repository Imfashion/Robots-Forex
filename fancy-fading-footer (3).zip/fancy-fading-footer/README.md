# Fancy Fading Footer

A Pen created on CodePen.io. Original URL: [https://codepen.io/Attire-/pen/rNEKoqW](https://codepen.io/Attire-/pen/rNEKoqW).

Made for this video: https://www.youtube.com/watch?v=--4n9c4-h1Y